#include<stdio.h>

int main(){
	float f1 = 1, f0 = 0, f2;
	int i, n = 50;
	for (i = 0; i< n; i++){
		f2 = f0+f1;
		f0 = f1;
		f1 = f2;
	}
	
	printf("50th fibonacci number is %f",f2);
	return 1;
}
